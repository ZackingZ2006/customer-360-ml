# Customer 360: dự đoán mua lại trong 90 ngày

Phần Machine Learning nối tiếp dự án SQL Customer 360 của Tech360 Retail. Dùng dữ liệu giả lập gốc năm 2025 để dự đoán hành vi tương lai của khách đã từng mua, so sánh model với quy tắc Recency/Frequency và báo cáo cả khi ML không tốt hơn.

## Mở gì trước?

1. `BAO_CAO.html`: báo cáo đọc ngay trên trình duyệt, có kết quả và biểu đồ.
2. `Customer360_ML.ipynb`: notebook có giải thích tiếng Việt và kết quả đã chạy.
3. `customer360_ml.py`: toàn bộ logic chuẩn bị dữ liệu, huấn luyện và đánh giá.
4. `NOTION_ML.md`: nội dung có thể bổ sung vào cuối bài Notion hiện có.

## Chạy lại trên máy của bạn

Khuyến nghị Python 3.12. Mở terminal tại thư mục chứa README:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe customer360_ml.py
.\.venv\Scripts\python.exe -m unittest test_temporal_integrity -v
```

Không cần chạy SQL Server để chạy bài này: hai CSV đầu vào đã có trong `data/`. Có thể dùng `python customer360_ml.py --data-dir <thu_muc_csv> --output-dir <thu_muc_ket_qua>`.

Notebook có thể mở bằng VS Code + Jupyter, hoặc tải cả thư mục lên môi trường notebook. Chọn kernel đã cài các thư viện trong requirements. Các đường dẫn trong code tương đối với thư mục dự án.

## Câu hỏi và nhãn

Tại ngày chốt T, trong số khách đã có ít nhất một đơn Completed từ 01/01/2025 đến T, ai có ít nhất một đơn Completed trong `(T, T + 90 ngày]`?

- Có: `repurchase_90d = 1`; không: `0`, nhưng chỉ khi quan sát đủ 90 ngày.
- Đầu vào dùng 90 ngày `[T - 89 ngày, T]`. Không dùng dữ liệu tương lai, ID, tên, loyalty tier chốt cuối năm, nhóm Champion/At Risk, hoặc trạng thái dịch vụ thiếu lịch sử.
- Khách có thể xuất hiện ở nhiều mốc vì mục tiêu là dự đoán lần mua tương lai của khách đã biết. Đây không phải phép đo khả năng dự đoán khách hoàn toàn mới.
- Khách chưa từng có đơn Completed trước ngày chốt không thuộc phạm vi model này.

## Thiết kế đánh giá đã cố định trước khi xem test

| Vai trò | Ngày chốt | Quan sát nhãn đến | Công dụng |
|---|---|---|---|
| Train | 31/03/2025 | 29/06/2025 | Fit model ban đầu |
| Validation | 30/06/2025 | 28/09/2025 | Chọn Logistic Regression hoặc Random Forest theo Average Precision |
| Test | 30/09/2025 | 29/12/2025 | Đánh giá model đã chọn, refit trên Train + Validation |

Nhãn Train hoàn tất trước Validation; nhãn Validation hoàn tất trước Test. Không chia ngẫu nhiên các dòng khách–ngày. Không tối ưu tham số, đặc trưng hoặc ngưỡng bằng Test. Chỉ có hai model với cấu hình cố định: Logistic Regression (`C=1`) và Random Forest (300 cây, độ sâu tối đa 4, ít nhất 15 mẫu/lá). StandardScaler nằm trong Pipeline và chỉ fit cùng tập huấn luyện.

Đối chứng gồm xác suất nền, ưu tiên khách mua gần đây, ưu tiên khách có nhiều đơn trong 90 ngày. Quy tắc mạnh nhất cũng được chọn bằng Validation. Chọn ML tốt nhất trong hai model không có nghĩa ML đã thắng quy tắc.

## Đọc chỉ số

- **Average Precision (AP)**: chất lượng xếp hạng trên nhiều ngưỡng; lớn hơn tốt hơn. Không gọi đây là diện tích PR tính bằng quy tắc hình thang.
- **ROC-AUC**: khả năng xếp người sẽ mua cao hơn người không mua.
- **Precision@20%**: tỷ lệ mua lại thực tế trong nhóm 20% điểm cao nhất. Ngân sách 20% là giả định minh họa, không được suy ra từ chi phí chiến dịch.
- **Lift@20%**: Precision@20% chia tỷ lệ mua lại của cả Test. Lift 1 là mức chọn ngẫu nhiên kỳ vọng.
- **Brier**: sai số xác suất, nhỏ hơn tốt hơn. Chỉ tính cho model trả xác suất.
- **Precision/Recall/Confusion matrix tại 0,5**: chỉ để minh họa phân loại; ngưỡng này chưa tối ưu theo chi phí kinh doanh.
- Khi điểm xếp hạng bằng nhau, phá hòa bằng SHA-256 của seed + ID, không dùng nhãn. Với đối chứng xác suất nền, top 20% là kỳ vọng chọn ngẫu nhiên.

Bootstrap chênh lệch AP sử dụng 1.000 lần lấy mẫu lại khách trong Test, cùng chỉ số lấy mẫu cho ML và quy tắc. Khoảng 95% chỉ phản ánh biến động khách của mốc Test này, có điều kiện trên model đã fit. Không đo biến động huấn luyện hoặc khác biệt mùa giữa các mốc.

## Kết quả được lưu

`results/` có số liệu từng tập, chỉ số Validation/Test, dự đoán Test có nhãn, tầm quan trọng đặc trưng, biểu đồ, khoảng bootstrap, dữ liệu đặc trưng và `run_manifest.json` chứa phiên bản thư viện + SHA-256 đầu vào. Các CSV kết quả là dữ liệu phân tích để code đọc, không phải workbook Excel.

`demo_scores_2025_12_31.csv` là chấm điểm hồi cứu tại 31/12/2025, dự đoán đến **31/03/2026**, bằng model refit trên ba mốc có nhãn. Bộ dữ liệu chỉ kết thúc năm 2025 nên **không có kết quả thực tế 2026 để kiểm chứng**. Không gán nhãn 0 cho phần tương lai này. File không phải danh sách nên liên hệ ở thời điểm hiện tại.

## Giới hạn cần giữ nguyên trong portfolio

1. Dữ liệu giả lập, 600 khách, một năm: kết quả chỉ minh họa quy trình và cấu trúc dữ liệu này.
2. Chỉ có một mốc Validation và một mốc Test. Chưa đủ kết luận độ ổn định qua nhiều mùa.
3. `order_status` là trạng thái cuối trong file, thiếu thời điểm Completed và nhật ký chỉnh sửa. Bài giả định trạng thái Completed cùng giá trị đơn đã biết vào `order_date`. Đây là giả định về thời điểm sẵn có dữ liệu, chưa phải dữ liệu lịch sử được tái dựng đầy đủ. Thực tế cần `completed_at` và lịch sử cập nhật để kiểm tra lại.
4. Lịch sử trước năm 2025 bị thiếu. “Đã từng mua” là trong cửa sổ dữ liệu quan sát được.
5. Điểm mua lại chưa được hiệu chỉnh xác suất riêng, không chứng minh tác động của ưu đãi. Khách có điểm cao có thể tự mua dù không được chăm sóc. Muốn đo hiệu quả giữ chân cần thử nghiệm có đối chứng và dữ liệu chi phí/lợi nhuận.
6. Tầm quan trọng đặc trưng chỉ là phân tích liên hệ, có thể bị chia sẻ giữa các biến tương quan; không chứng minh quan hệ nhân quả.

## Nguồn

Dữ liệu từ bộ Customer360_PowerBI/Data đã có của người dùng: sao chép nguyên hai file `dim_customer.csv` và `fact_order.csv`. Đối soát 600 khách, 3.200 đơn, 2.998 Completed, 53.357.307.150 VND doanh thu Completed. Sáu bảng khác không cần cho phiên bản ML đầu tiên này. SHA-256 của bản sao có trong manifest.

Bối cảnh: https://app.notion.com/p/Customer-360-cho-chu-i-b-n-l-thi-t-b-i-n-t-3ad24d1b4aa180d9af83cefd8785196c

Tài liệu phương pháp: [scikit-learn về data leakage và Pipeline](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage), [định nghĩa Average Precision](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html).
