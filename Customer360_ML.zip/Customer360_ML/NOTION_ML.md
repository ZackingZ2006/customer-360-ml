# PHẦN 5: MACHINE LEARNING — DỰ ĐOÁN MUA LẠI TRONG 90 NGÀY

## Mục tiêu

Mở rộng dự án SQL Customer 360 bằng mô hình dự đoán khách đã từng có đơn Completed sẽ có ít nhất một đơn Completed trong 90 ngày tiếp theo. Đơn vị dữ liệu là một khách hàng tại một ngày chốt. Đây là dự đoán mua lại trong một cửa sổ xác định; không gán “rời bỏ vĩnh viễn” cho khách không mua thiết bị điện tử trong 90 ngày.

## Dữ liệu và đặc trưng

Dùng hai bảng gốc dim_customer (600 khách) và fact_order (3.200 đơn, gồm 2.998 Completed). Các tập này là những khách đã có ít nhất một đơn Completed trước hoặc tại ngày chốt. Khách chưa từng mua không thuộc phạm vi dự đoán.

Chín đặc trưng: recency chặn tại 91 ngày, số đơn 90 ngày và 30 ngày, log1p doanh thu 90 ngày và 30 ngày, log1p AOV 90 ngày, log1p đơn lớn nhất 90 ngày, số kênh mua, số khoảng 30 ngày có mua. Mọi phép tổng hợp dùng dữ liệu không muộn hơn ngày chốt. Không dùng tên/ID, loyalty tier chốt cuối năm, phân khúc SQL hoặc trạng thái dịch vụ chưa có lịch sử.

## Chia dữ liệu theo thời gian

| Tập | Ngày chốt | Kết thúc nhãn 90 ngày | Khách | Có mua lại | Tỷ lệ |
|---|---|---|---:|---:|---:|
| train | 2025-03-31 | 2025-06-29 | 283 | 201 | 71.0% |
| validation | 2025-06-30 | 2025-09-28 | 397 | 267 | 67.3% |
| test | 2025-09-30 | 2025-12-29 | 489 | 315 | 64.4% |


Ở mỗi mốc, đầu vào có 90 ngày lịch sử tính cả ngày chốt. Nhãn chỉ tính ngày sau ngày chốt đến hết ngày thứ 90. Nhãn Train hoàn tất trước Validation; nhãn Validation hoàn tất trước Test. Cùng một khách có thể xuất hiện ở nhiều mốc vì mục tiêu là dự đoán tương lai của khách đã biết, không phải khách mới hoàn toàn.

## Huấn luyện và lựa chọn

So sánh Logistic Regression (StandardScaler trong Pipeline, C=1) và Random Forest (300 cây, sâu tối đa 4, ít nhất 15 mẫu/lá), với cấu hình cố định. Chọn ML theo Average Precision trên Validation: **logistic_regression**. Quy tắc đối chứng cũng chọn bằng Validation: **frequency_rule**.

Sau khi chốt lựa chọn, fit lại ML trên Train + Validation để đánh giá Test. Không dùng Test chọn tham số, đặc trưng hoặc ngưỡng. Ngưỡng phân loại 0,5 và nhóm 20% điểm cao nhất được đặt trước để minh họa, chưa tối ưu theo chi phí kinh doanh.

## Kết quả Test

| Phương pháp | AP | ROC-AUC | Precision@20% | Lift@20% |
|---|---:|---:|---:|---:|
| logistic_regression | 0.729 | 0.579 | 74.5% | 1.16 |
| recency_rule | 0.729 | 0.606 | 78.6% | 1.22 |
| frequency_rule | 0.712 | 0.583 | 76.5% | 1.19 |
| constant_prior | 0.644 | 0.500 | 64.4% | 1.00 |


**logistic_regression có AP Test 0.729, cao hơn frequency_rule (0.712).** Tỷ lệ mua lại của cả Test là **64.4%**. Trong 98 khách có điểm ML cao nhất, **74.5%** có mua lại, tương ứng lift **1.16** lần mức chọn ngẫu nhiên kỳ vọng. Đây là kết quả xếp hạng hồi cứu, không phải hiệu quả tăng thêm của chiến dịch.

Quy tắc mua gần đây có AP 0.7293 và Precision@20% 78.6%; ML có AP 0.7287 và Precision@20% 74.5%. ML chưa cho thấy lợi thế rõ ràng trước các quy tắc đơn giản. Accuracy ML 60.9% tại ngưỡng 0,5 còn thấp hơn cách luôn đoán mua lại (64.4%); không dùng riêng accuracy để tuyên bố thành công.

Chênh lệch AP ML − quy tắc được chọn: **+0.016**; khoảng bootstrap 95%: **[+0.005; +0.028]** từ 1000 lần lấy mẫu lại khách Test. Khoảng bootstrap không chứa 0, nhưng chỉ phản ánh mẫu khách tại một mốc Test; cần thêm mốc kiểm tra độc lập.

Với ngưỡng 0,5, Precision = 67.3%, Recall = 76.5%, Accuracy = 60.9%; TN=57, FP=117, FN=74, TP=241. Brier = 0.229. Ngưỡng chưa dựa trên giá trị đơn hoặc chi phí liên hệ.

![Biểu đồ đánh giá Test](results/evaluation.png)

AP là Average Precision; lớn hơn tốt hơn. Precision@20% là tỷ lệ mua lại trong 20% khách đứng đầu; Lift@20% chia tỷ lệ đó cho tỷ lệ mua lại chung. Đối chứng xác suất nền không phân hạng được nên top 20% được ghi theo kỳ vọng chọn ngẫu nhiên. Điểm bằng nhau ở các phương pháp xếp hạng được phá hòa bằng hash cố định, không dùng nhãn.

## Kết luận và ứng dụng

logistic_regression có AP Test 0.729, cao hơn frequency_rule (0.712). Khoảng bootstrap không chứa 0, nhưng chỉ phản ánh mẫu khách tại một mốc Test; cần thêm mốc kiểm tra độc lập. Kết quả này cho biết giá trị bổ sung của model so với quy tắc trong dữ liệu giả lập hiện có. Không nên khẳng định ML hiệu quả hơn chỉ vì đã huấn luyện được một model.

Không khuyến nghị thay quy tắc hiện có bằng ML dựa trên lần kiểm tra này. Cần thêm dữ liệu, mốc thời gian độc lập và mục tiêu chi phí cụ thể trước khi quyết định.

Điểm mua lại có thể dùng làm một biến đầu vào khi thiết kế thử nghiệm CRM. Điểm cao không có nghĩa cần tặng ưu đãi: khách có thể tự mua. Điểm thấp cũng không chứng minh ưu đãi sẽ giữ được khách. Cần thử nghiệm có đối chứng, cập nhật opt-in/trạng thái dịch vụ và đo lợi nhuận tăng thêm trước khi triển khai.

## Giới hạn

- Dữ liệu giả lập, chỉ 600 khách và một năm. Chỉ có một mốc Test, chưa kiểm chứng nhiều mùa hoặc dữ liệu thật.
- Thiếu completed_at và lịch sử thay đổi đơn. Bài giả định trạng thái cuối Completed và giá trị đơn đã biết vào order_date; chưa xác minh được thời điểm sẵn có thực tế của các trường này.
- Thiếu lịch sử trước 2025. “Đã từng mua” chỉ tính trong dữ liệu quan sát.
- Khoảng bootstrap chỉ phản ánh mẫu khách tại một mốc, không bao gồm độ bất định huấn luyện hoặc biến động theo mùa.
- Phân tích tầm quan trọng đặc trưng không chứng minh quan hệ nhân quả. Xác suất chưa được hiệu chỉnh riêng.

## Bàn giao

Notebook Customer360_ML.ipynb, pipeline customer360_ml.py, dữ liệu gốc, kết quả CSV, manifest và kiểm tra temporal integrity được kèm cùng dự án. File demo_scores_2025_12_31.csv chấm điểm 575 khách tại 31/12/2025 đến 31/03/2026; **không có nhãn thực tế năm 2026**, nên chỉ là minh họa hồi cứu, chưa xác nhận dự đoán đúng.

Nguồn bối cảnh: [Customer 360 của người dùng](https://app.notion.com/p/Customer-360-cho-chu-i-b-n-l-thi-t-b-i-n-t-3ad24d1b4aa180d9af83cefd8785196c). Phương pháp: [scikit-learn — tránh data leakage](https://scikit-learn.org/stable/common_pitfalls.html#data-leakage), [Average Precision](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html).
